
// Olivia Duong RUID: 192002200 NetID: ond3

// Packages needed for program to run
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>


int occurencesCount_function(char* PassedFileText, char* FindingSubString);

int main(int argc,char* argv[])
{
    FILE* fp;
    fp = fopen(argv[1],"r");

    if(fp == NULL)
    {
        perror("./p01"); // error message with no message passed
        return -1;
    }

    int systemCall_checknum = 0 ;
    for(int a = 0; a < argc ; a++) // for loop to go through arguments to check for "--systemcall"
    {
        if(strstr(argv[a],"--systemcalls"))
            systemCall_checknum = 1;
    }
    

    if(argc == 3) // 3 arguments only
    {
        fseek(fp,0, SEEK_END);
        int filesize = ftell(fp);
        fseek(fp,0,SEEK_SET);
        char* fileString = (char*)malloc(filesize*sizeof(char) + 1);
        fread(fileString, 1,filesize,fp); 
        fileString[filesize] = '\0';

        int occurenceResult = occurencesCount_function(fileString,argv[2]);

        printf("%d\n", occurenceResult); // print the occurence count
        return 0;
    }


    if(argc >= 4 && strcmp(argv[2],"--systemcalls")!=0 ) // 4 arguments only with no system calls
    {
        fseek(fp,0, SEEK_END);
        int filesize = ftell(fp);
        fseek(fp,0,SEEK_SET);
        char* fileString = (char*)malloc(filesize*sizeof(char) + 1);
        fread(fileString, 1,filesize,fp); 
        fileString[filesize] = '\0';
        int argCount = 2;

        while(argv[argCount] != NULL)
        {
            int occurenceResult = occurencesCount_function(fileString,argv[argCount]);

            printf("%d\n", occurenceResult); // printing the occurence count
            argCount++; // argument counter increment +1 for every loop
        }
        return 0;
    }

    if(argc >= 4 && strcmp(argv[2],"--systemcalls")==0) // more than 4 arguments with systemcalls
    {
        
        int filedirectory = open(argv[1],O_RDONLY); //read only
        int buffSize = 1000;
        char* fileString = (char*)malloc(buffSize*sizeof(char));
        read(filedirectory,fileString,1000);

        printf("%s\n",fileString); // print statement to print string of file

        int argCount = 3;
        while(argv[argCount] != NULL) // loop will proceed from argv[3]
        {
            int occurenceResult = occurencesCount_function(fileString,argv[argCount]);

            printf("%d\n", occurenceResult); // printing the occurence count
            argCount++; // increment
        }

        free(fileString);
        close(filedirectory);
        return 0;
    }
}

int occurencesCount_function(char* PassedFileText, char* FindingSubString) // OccurenceCountFunction will count the occurences 
{
    int occurencesCount = 0;
    int substringLength_find =  strlen(FindingSubString);
    int filetextLength_find = strlen(PassedFileText);
    char fileUppercase[filetextLength_find];
    char substringUppercase[substringLength_find];

    // for loop to make all the the letters in findingsubstring uppercase to avoid any case sensitive issues
    for(int a = 0 ;FindingSubString[a]; a++)
    {
        substringUppercase[a] = toupper(FindingSubString[a]);
    }

    // for loop to make all the the letters in fileuppercase to avoid any case sensitive issues
    for(int b = 0; PassedFileText[b]; b++)
    {
        fileUppercase[b] = toupper(PassedFileText[b]);
    }

    // Camparison between chars passedfile and substringfile
    for(int start = 0; start <= filetextLength_find-substringLength_find;start++)
    {
        int charCount = 0;
        for(charCount = 0; charCount < substringLength_find;charCount++)
        {

            // Checks if substring letter matches passsedfile letter
            if(substringUppercase[charCount] == fileUppercase[start+charCount])
            {
               continue;
            }

            else
            {
                break;
            }

        }
           if(charCount == substringLength_find)
           {
                occurencesCount++;
           }
    }
       return occurencesCount;
}
