
How to Compile & Test Problem 5: Process

Contents needed: 
- server.c
- client.c
- Makefile 

Ensure that you are in the correct directory:
- Utilize pwd or cd ~ on MacOS 
- Delete existing any .exec files to start fresh

Steps in Terminals:
1) Open 2 split terminals (preferably side by side)
2) make (only once is needed)
3) In one terminal, type ./server first (has to be server first)
4) In the other terminal, type ./client 
5) First Output in Server: [From Client]: Network-Centric Programming - Spring 2023 Midterm
6) Second Output after 5 seconds in Client: [From Server]: Good luck with your exam!

If the process in server terminal has not yet been killed, once can do ps and kill or ctrl-z.


