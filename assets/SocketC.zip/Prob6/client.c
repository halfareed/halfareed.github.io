/*
Author: Olivia Duong
NetID: ond3
RUID: 192002200

Socket: CLIENT

Socket Programming Basics Analogy
Goal: Client Socket has to receive: "Good luck with your exam!"

socket() - endpoint for communication
bind() - assigns a unique telephone number
listen() - wait for a caller 
connect() - dial a number 
accept() - receive a call 
send(), recv() - talk
close() - hang up
*/

// header files

#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main()
{

	char *ip = "127.0.0.1"; // local address
	int port = 8819; // ensure same port on both server & client
	int client_sock; // initalize client socket

	struct sockaddr_in client_address;
	socklen_t addr_size;
	char buffer[1024]; // length of message buffer
	int n; // for bind
	client_sock = socket(AF_INET, SOCK_STREAM, 0);

	if (client_sock < 0) // error
	{
		perror("Socket Creation Failed");
		exit(1);
	}

	// if not error, then client socket is created

	memset(&client_address, '\0', sizeof(client_address));
	client_address.sin_family = AF_INET;
	client_address.sin_port = port; // recalled in line 18
	client_address.sin_addr.s_addr = inet_addr(ip);

	// connect to server

	connect(client_sock, (struct sockaddr*)&client_address, sizeof(client_address));

	sleep(1);
	bzero(buffer, 1024);
	strcpy(buffer, "[From Client]: Network-Centric Programming - Spring 2023 Midterm"); // message to server
	// FORMAT OF SEND: send(sock, buffer, length of message, 0);
	send(client_sock, buffer, strlen(buffer), 0); // sending to server
	
	bzero(buffer, 1024);
	recv(client_sock, buffer, sizeof(buffer), 0); // receiving message from server
	printf("[From Server]: %s\n", buffer); // prints message from server
	
	close(client_sock); // client disconnected from server

	return 0;
}
