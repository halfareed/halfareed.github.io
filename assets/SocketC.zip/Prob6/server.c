/*
Author: Olivia Duong
NetID: ond3
RUID: 192002200

Socket: SERVER
Goal: Server Socket has to receive: "Network-Centric Programming - Spring 2023 Midterm"

Socket Programming Basics Analogy

socket() - endpoint for communication
bind() - assigns a unique telephone number
listen() - wait for a caller 
connect() - dial a number 
accept() - receive a call 
send(), recv() - talk
close() - hang up
*/

// header files

#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>


int main()
{

	char *ip = "127.0.0.1";  // local address
	int port = 8819; // ensure same port on both server & client
	int server_sock, client_sock; // initalize server socket 

	struct sockaddr_in server_address, client_address;
	socklen_t address_size;
	char buffer[1024]; // length of message buffer
	int n; // for bind
	server_sock = socket(AF_INET, SOCK_STREAM, 0);

	if (server_sock < 0) // error
	{
		perror("Socket Creation Failed");
		exit(1);
	}
	
	// if not error, then server socket is created

	memset(&server_address, '\0', sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_port = port; // recalled in line 18
	server_address.sin_addr.s_addr = inet_addr(ip);

	// bind address and port number

	n = bind(server_sock, (struct sockaddr *)&server_address, sizeof(server_address));
	if (n < 0)
	{
		perror("Bind error.");
		exit(1);
	}

	// listen for the client 

	listen(server_sock, 5); // max of 5 lines

	// accept connections from client 1 at a time

	while(1)
	{
		address_size = sizeof(client_address);
		client_sock = accept(server_sock, (struct sockaddr*)&client_address,&address_size); // client connected

		bzero(buffer, 1024);
		recv(client_sock, buffer, sizeof(buffer), 0); // receiving message from client
		printf("%s\n", buffer); // prints message from client
		sleep(5); // sleep for 5 seconds before sending message to client

		bzero(buffer, 1024);
		strcpy(buffer, "Good luck with your exam!"); // message to back to client
		send(client_sock, buffer, strlen(buffer), 0); // sending to client
		
		close(client_sock); // client disconnects from server
		exit(0); // close server/program or you can do sighandler or ctrl z
		
	}

	
	return 0;
}
