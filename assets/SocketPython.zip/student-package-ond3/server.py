import threading
import time
import random

import socket

def server():
    try:
        ss = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("[S]: Server socket created")
    except socket.error as err:
        print('socket open error: {}\n'.format(err))
        exit()

    server_binding = ('', 50020)
    ss.bind(server_binding)
    ss.listen(1)
    host = socket.gethostname()
    print("[S]: Server host name is {}".format(host))
    localhost_ip = (socket.gethostbyname(host))
    print("[S]: Server IP address is {}".format(localhost_ip))
    csockid, addr = ss.accept()
    print ("[S]: Got a connection request from a client at {}".format(addr))

    # send a intro message to the client.  # msg = "Welcome to CS 352!" # csockid.send(msg.encode('utf-8'))
    #------------------------------------------------------------------#
    data = csockid.recv(1024) # encoded message recieved by client
    dataResult = data.decode('utf-8') # decode message recieved by client
    #------------------------------------------------------------------#
    reverse1 = dataResult[::-1] # reverse encoded message
    split = reverse1.splitlines() 
    reverse2 = split[::-1]
    reverseResult = '\n'.join(reverse2)

    file1 = open("outr-proj.txt", "w") # create new file
    file1.write(reverseResult) # overwrite content
    #------------------------------------------------------------------#
    uppercaseResult = dataResult.upper() # uppercase encoded message
    file2 = open("outup-proj.txt", "w") # create new file
    file2.write(uppercaseResult) # overwrite content
    #------------------------------------------------------------------#
    result = (f"Sent by client: {dataResult}. \nReceived in reverse: {reverseResult}. \nReceived in uppercase: {uppercaseResult}.")
    csockid.sendall(result.encode('utf-8')) # send encoded message back to client to be printed
    #------------------------------------------------------------------#

    # Close the server socket
    ss.close()
    exit()

if __name__ == "__main__":
    t1 = threading.Thread(name='server', target=server)
    t1.start()

    time.sleep(5)
    print("Done.")