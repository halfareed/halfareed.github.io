import socket
import signal
import sys
import random

# Read a command line argument for the port where the server
# must run.
port = 8080
if len(sys.argv) > 1:
    port = int(sys.argv[1])
else:
    print("Using default port 8080")

# Start a listening server socket on the port
sock = socket.socket()
sock.bind(('', port))
sock.listen(2)

### Contents of pages we will serve.
# Login form
login_form = """
   <form action = "http://localhost:%d" method = "post">
   Name: <input type = "text" name = "username">  <br/>
   Password: <input type = "text" name = "password" /> <br/>
   <input type = "submit" value = "Submit" />
   </form>
""" % port
logout_form = """
    <form action = "http://localhost:%d" method = "post">
    </form>
""" % port
# Default: Login page.
login_page = "<h1 style='color:DodgerBlue;'>Please login</h1>" + login_form
# Error page for bad credentials
bad_creds_page = "<h1 style='color:Red;'>Bad user/pass! Try again</h1>" + login_form
# Successful logout
logout_page = "<h1 style='color:Tomato;'>Logged out successfully</h1>" + logout_form
# A part of the page that will be displayed after successful
# login or the presentation of a valid cookie
success_page = """
   <h1 style='color:Green;'>Welcome!</h1>
   <form action="http://localhost:%d" method = "post">
   <input type = "hidden" name = "password" value = "new" />
   <input type = "submit" value = "Click here to Change Password" />
   </form>
   <form action="http://localhost:%d" method = "post">
   <input type = "hidden" name = "action" value = "logout" />
   <input type = "submit" value = "Click here to logout" />
   </form>
   <br/><br/>
   <h1 style='color:magenta;'>Your secret data is here:</h1>
""" % (port, port)

new_password_page = """
   <form action="http://localhost:%d" method = "post">
   New Password: <input type = "text" name = "NewPassword" /> <br/>
   <input type = "submit" value = "Submit" />
</form>
""" % port


#### Helper functions
# Printing.
def print_value(tag, value):
    print ("Here is the", str(tag))
    print ("\"\"\"")
    print (str(value))
    print ("\"\"\"")
    print


# Signal handler for graceful exit
def sigint_handler(sig, frame):
    print('Finishing up by closing listening socket...')
    sock.close()
    sys.exit(0)


# Register the signal handler
signal.signal(signal.SIGINT, sigint_handler)

# TODO: put your application logic here!
actions = ['action=logout', 'password=new', 'NewPassword', 'username', 'password', 'Cookie']
# Username token dictionary
userTokenDictionary = {}
# Read login credentials for all users
credentialsdictionary = {}
with open('passwords.txt') as passwords:
    credentialsdictionary = {line.strip().split()[0]: line.strip().split()[1] for line in passwords}

# Read secret data of all users
secretdictionary = {}
with open('secrets.txt') as secrets:
    secretdictionary = {username: secret for username, secret in (item.strip().split() for item in secrets)}


def rewritePassword(username, rewrittenPassword):
    credentialsdictionary[username] = rewrittenPassword
    with open('passwords.txt', 'w') as passwords:
        passwords.writelines('{} {}\n'.format(user, pw) for user, pw in credentialsdictionary.items())


### Loop to accept incoming HTTP connections and respond.
while True:
    client, addr = sock.accept()
    req = client.recv(1024)

    # Let's pick the headers and entity body apart
    header_body = req.split('\r\n\r\n')
    headers = header_body[0]
    body = '' if len(header_body) == 1 else header_body[1]
    print_value('headers', headers)
    print_value('entity body', body)
    # TODO: Put your application logic here!
    # Parse headers and body and perform various actions
    if actions[0] in body:  # logout
        # If the logout action is in the entity body, set the cookie to expire and return the logout page.
        html_content_to_send, headers_to_send = logout_page, 'Set-Cookie: token=; expires=Thu, 01 Jan 1970 00:00:00 ' \
                                                             'GMT\r\n '

    elif actions[1] in body:  # change password is clicked
        # New password action.
        html_content_to_send, headers_to_send = new_password_page, ''

    elif actions[2] in body:  # new password inserted
        # If the update password action is in the entity body, update the password and return the success page with
        # secret data.
        rewrittenPassword = body.split('=')[1].split('&')[0]
        rewritePassword(username, rewrittenPassword)
        html_content_to_send, headers_to_send = success_page + secretdictionary[username], ''

    elif actions[3] in body and actions[4] in body:  # username, password
        # If login credentials are in the entity body, check the credentials and set a new token if the login is
        # successful.
        username, password = body.split('&')[0].split('=')[1], body.split('&')[1].split('=')[1]
        if username in credentialsdictionary and credentialsdictionary[username] == password:
            # Successful login. Generate a new token and return the success page with secret data.
            rand_val = int(random.getrandbits(64))
            userTokenDictionary[rand_val] = username
            headers_to_send = "Set-Cookie: token={}\r\n".format(rand_val)
            html_content_to_send = success_page + secretdictionary.get(username, '')
        else:
            # Bad credentials. Return the bad credentials page.
            headers_to_send, html_content_to_send = '', bad_creds_page

    elif actions[5] in headers:  # cookie in headers
        # If there is a cookie in the headers, check if it's valid and return the success page with secret data if it
        # is.
        token = headers.split('Cookie: ')[1].split('=')[1].split('\r\n')[0]
        if token and int(token) in userTokenDictionary:
            # Valid cookie. Return the success page with secret data.
            username = userTokenDictionary[int(token)]
            html_content_to_send, headers_to_send = success_page + secretdictionary[username], ''
        else:
            # Invalid cookie. Return the login page.
            headers_to_send, html_content_to_send = '', login_page

    else:
        # If none of the above conditions are met, return the login page.
        html_content_to_send, headers_to_send = login_page, ''

    # Construct and send the final response
    response = 'HTTP/1.1 200 OK\r\n'
    response += headers_to_send
    response += 'Content-Type: text/html\r\n\r\n'
    response += html_content_to_send
    print_value('response', response)
    client.send(response)
    client.close()

    print ("Served one request/connection!")
    print ()

# We will never actually get here.
# Close the listening socket
sock.close()
